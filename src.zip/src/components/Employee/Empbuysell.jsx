import React from 'react'

const Empbuysell = () => {
  return (
    <div>
      
    </div>
  )
}

export default Empbuysell
