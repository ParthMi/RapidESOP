import React from 'react'

const Allcompany = () => {
  return (
    <div>
      
    </div>
  )
}

export default Allcompany
