import React from 'react'

const EmpTransactions = () => {
  return (
    <div>
      
    </div>
  )
}

export default EmpTransactions
